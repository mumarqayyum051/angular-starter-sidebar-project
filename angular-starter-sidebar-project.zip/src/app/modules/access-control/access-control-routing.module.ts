import { AccessControlComponent } from './access-control.component';

export const Routes = [{ path: '', component: AccessControlComponent }];
