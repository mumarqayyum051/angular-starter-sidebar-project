import { FeedComponent } from './feed.component';

export const Routes = [{ path: '', component: FeedComponent }];
