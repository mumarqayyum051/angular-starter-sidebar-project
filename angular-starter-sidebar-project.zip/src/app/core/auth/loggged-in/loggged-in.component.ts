import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loggged-in',
  templateUrl: './loggged-in.component.html',
  styleUrls: ['./loggged-in.component.scss']
})
export class LogggedInComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
